"""Request-side access-token verification -> the authenticated caller.

Two kinds of RS256 bearer tokens, both signed by restaurant-mgmt's KMS key:

* **User tokens** (aud ``settings.jwt_audience``, "sg-platform") -- admin / back-office users.
  Protected admin routes call :func:`authenticate`.
* **Employee tokens** (aud ``settings.pos_jwt_audience``, "sg-pos", ``typ="employee"``) -- a store
  employee signed in on a registered POS device with their store PIN. POS routes call
  :func:`authenticate_employee`. Because the audience differs, an employee token can never pass
  :func:`authenticate` (and vice versa), so an Owner employee's ``"*"`` never reaches admin APIs.

Any failure raises :class:`UnauthorizedError`.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Protocol
from uuid import UUID

import jwt

from sg_commons.config import Settings
from sg_commons.crypto import tokens
from sg_commons.crypto.signer import Signer
from sg_commons.errors import ForbiddenError, UnauthorizedError

EMPLOYEE_TOKEN_TYPE = "employee"


class _HasClaims(Protocol):
    @property
    def claims(self) -> dict[str, Any]: ...


@dataclass(frozen=True)
class AuthContext:
    user_id: UUID
    tenant_id: UUID
    email: str
    claims: dict[str, Any]


@dataclass(frozen=True)
class EmployeeContext:
    """A store employee signed in on a POS device (see module docstring)."""

    employee_id: UUID
    tenant_id: UUID
    store_id: UUID
    device_id: UUID
    role: str
    claims: dict[str, Any]

    @property
    def permissions(self) -> list[str]:
        return list(self.claims.get("permissions") or [])


def _bearer(authorization: str | None) -> str:
    if not authorization or not authorization.lower().startswith("bearer "):
        raise UnauthorizedError("missing or malformed Authorization header")
    return authorization[len("bearer ") :].strip()


def authenticate(authorization: str | None, signer: Signer, settings: Settings) -> AuthContext:
    token = _bearer(authorization)
    try:
        claims = tokens.decode_access_token(
            token,
            jwk=signer.public_jwk(),
            issuer=settings.jwt_issuer,
            audience=settings.jwt_audience,
        )
        if claims.get("typ") == EMPLOYEE_TOKEN_TYPE:  # defence in depth (audience differs too)
            raise ValueError("employee token on a user route")
        return AuthContext(
            user_id=UUID(claims["sub"]),
            tenant_id=UUID(claims["tenant_id"]),
            email=claims["email"],
            claims=claims,
        )
    except (jwt.InvalidTokenError, ValueError, KeyError) as exc:
        raise UnauthorizedError("invalid access token") from exc


def authenticate_employee(
    authorization: str | None, signer: Signer, settings: Settings
) -> EmployeeContext:
    """Verify a POS employee token (aud ``pos_jwt_audience``, ``typ="employee"``)."""
    token = _bearer(authorization)
    try:
        claims = tokens.decode_access_token(
            token,
            jwk=signer.public_jwk(),
            issuer=settings.jwt_issuer,
            audience=settings.pos_jwt_audience,
        )
        if claims.get("typ") != EMPLOYEE_TOKEN_TYPE:
            raise ValueError("not an employee token")
        return EmployeeContext(
            employee_id=UUID(claims["sub"]),
            tenant_id=UUID(claims["tenant_id"]),
            store_id=UUID(claims["store_id"]),
            device_id=UUID(claims["device_id"]),
            role=str(claims.get("role") or ""),
            claims=claims,
        )
    except (jwt.InvalidTokenError, ValueError, KeyError) as exc:
        raise UnauthorizedError("invalid employee token") from exc


def has_permission(ctx: _HasClaims, permission: str) -> bool:
    """True if the caller holds ``permission`` (or the wildcard ``"*"``)."""
    perms = ctx.claims.get("permissions") or []
    return "*" in perms or permission in perms


def require_permission(ctx: _HasClaims, permission: str) -> None:
    """Raise :class:`ForbiddenError` unless the caller holds ``permission`` (or ``"*"``)."""
    if not has_permission(ctx, permission):
        raise ForbiddenError(f"missing permission: {permission}")
