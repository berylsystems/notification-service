"""Runtime configuration, loaded from environment (prefix ``SG_``)."""

from __future__ import annotations

from functools import lru_cache

from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_prefix="SG_", env_file=".env", extra="ignore")

    env: str = "local"
    aws_region: str = "ap-south-1"  # Mumbai — India market

    # The application connects as a NON-superuser role so Row-Level Security is enforced.
    database_url: str = "postgresql+psycopg://sg_app:sg_app_pw@localhost:5432/sg_user"

    # Data tier (set by CDK in AWS). When db_secret_arn + db_host are set, the engine URL is
    # built from the Secrets Manager secret and connects over TLS; otherwise database_url is
    # used (local/dev/tests). db_host is the RDS Proxy endpoint (prod) or the Aurora cluster
    # endpoint (dev, DB-out-of-VPC).
    db_secret_arn: str | None = None
    db_host: str | None = None
    db_port: int = 5432
    db_name: str = "sg_user"

    # JWT / token settings (used from Phase 1 onward).
    jwt_issuer: str = "https://auth.sg.local"
    jwt_audience: str = "sg-platform"
    # Employee (store-PIN) tokens used by the POS apps carry a DIFFERENT audience, so admin
    # routes (which check ``jwt_audience``) reject them -- an Owner employee's "*" never reaches
    # admin APIs.
    pos_jwt_audience: str = "sg-pos"
    access_token_ttl_seconds: int = 900  # 15 minutes
    refresh_token_ttl_seconds: int = 2_592_000  # 30 days
    reset_token_ttl_seconds: int = 1_800  # 30 minutes
    kms_signing_key_id: str | None = None  # KMS asymmetric RSA key id/arn; set by infra
    kms_data_key_id: str | None = None  # KMS symmetric CMK for field envelope encryption

    # Dev-only: return the password-reset token in the /auth/password/forgot response.
    # MUST stay False outside local dev (real delivery is email/SMS, added later).
    expose_reset_token: bool = False

    # Hardening (Phase 4): account lockout + password policy.
    min_password_length: int = 8
    lockout_threshold: int = 5  # failed logins within the window before lockout
    lockout_window_seconds: int = 900  # 15 minutes

    # Onboarding document uploads (Increment B).
    s3_user_objects_bucket: str | None = None  # set by infra
    s3_menu_images_bucket: str | None = None  # menu dish photos; set by infra
    presign_expiry_seconds: int = 900  # 15 minutes
    max_image_bytes: int = 10 * 1024 * 1024  # 10 MB
    max_pdf_bytes: int = 20 * 1024 * 1024  # 20 MB
    max_profile_pictures: int = 5

    # Stock-image import providers (Unsplash / Pexels). Keys come from a Secrets Manager secret
    # (image_providers_secret_arn, set by infra) as {"unsplash_access_key", "pexels_api_key"};
    # the direct fields are a local/dev fallback.
    image_providers_secret_arn: str | None = None
    unsplash_access_key: str | None = None
    pexels_api_key: str | None = None


@lru_cache
def get_settings() -> Settings:
    return Settings()
