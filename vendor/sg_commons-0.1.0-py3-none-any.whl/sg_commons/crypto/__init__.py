"""Cryptographic primitives: password hashing, JWT signing, token helpers."""
