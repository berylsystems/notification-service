"""RS256 signers and JWK publication.

Two implementations behind one :class:`Signer` protocol:

* :class:`KmsSigner` — production. The RSA private key never leaves AWS KMS; signing is a
  ``kms.sign`` call (``RSASSA_PKCS1_V1_5_SHA_256`` == JWT ``RS256``).
* :class:`LocalRsaSigner` — local dev / tests. An in-process RSA key.

Both publish their public key as a JWK (for ``/.well-known/jwks.json``) so any validator —
the menu module's API Gateway JWT authorizer, or PyJWT in tests — can verify tokens.
"""

from __future__ import annotations

import base64
from typing import Protocol, runtime_checkable

from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import padding, rsa
from cryptography.hazmat.primitives.asymmetric.rsa import RSAPrivateKey, RSAPublicKey
from cryptography.hazmat.primitives.serialization import load_der_public_key


def _b64url_uint(value: int) -> str:
    length = (value.bit_length() + 7) // 8
    return base64.urlsafe_b64encode(value.to_bytes(length, "big")).rstrip(b"=").decode()


def _rsa_public_jwk(public_key: RSAPublicKey, kid: str) -> dict[str, str]:
    numbers = public_key.public_numbers()
    return {
        "kty": "RSA",
        "use": "sig",
        "alg": "RS256",
        "kid": kid,
        "n": _b64url_uint(numbers.n),
        "e": _b64url_uint(numbers.e),
    }


@runtime_checkable
class Signer(Protocol):
    """Signs the JWT signing input and publishes its verification key."""

    @property
    def kid(self) -> str: ...

    def sign(self, message: bytes) -> bytes:
        """Return the raw RS256 (PKCS#1 v1.5, SHA-256) signature over ``message``."""
        ...

    def public_jwk(self) -> dict[str, str]:
        """Return the public verification key as a JWK."""
        ...


class LocalRsaSigner:
    """In-process RSA signer for local dev and tests. Never used in production."""

    def __init__(self, private_key: RSAPrivateKey, kid: str = "local-dev") -> None:
        self._key = private_key
        self._kid = kid

    @classmethod
    def ephemeral(cls, kid: str = "local-dev") -> LocalRsaSigner:
        key = rsa.generate_private_key(public_exponent=65537, key_size=2048)
        return cls(key, kid)

    @property
    def kid(self) -> str:
        return self._kid

    def sign(self, message: bytes) -> bytes:
        return self._key.sign(message, padding.PKCS1v15(), hashes.SHA256())

    def public_jwk(self) -> dict[str, str]:
        return _rsa_public_jwk(self._key.public_key(), self._kid)

    def public_pem(self) -> bytes:
        return self._key.public_key().public_bytes(
            serialization.Encoding.PEM,
            serialization.PublicFormat.SubjectPublicKeyInfo,
        )


class KmsSigner:
    """Signs via AWS KMS asymmetric RSA key. The private key never leaves KMS."""

    def __init__(self, key_id: str, *, region: str, kid: str | None = None) -> None:
        import boto3  # type: ignore[import-untyped]

        self._kms = boto3.client("kms", region_name=region)
        self._key_id = key_id
        self._kid = kid or key_id
        self._jwk: dict[str, str] | None = None

    @property
    def kid(self) -> str:
        return self._kid

    def sign(self, message: bytes) -> bytes:
        resp = self._kms.sign(
            KeyId=self._key_id,
            Message=message,
            MessageType="RAW",
            SigningAlgorithm="RSASSA_PKCS1_V1_5_SHA_256",
        )
        signature: bytes = resp["Signature"]
        return signature

    def public_jwk(self) -> dict[str, str]:
        if self._jwk is None:
            resp = self._kms.get_public_key(KeyId=self._key_id)
            public_key = load_der_public_key(resp["PublicKey"])
            assert isinstance(public_key, RSAPublicKey)  # KMS SIGN_VERIFY RSA key
            self._jwk = _rsa_public_jwk(public_key, self._kid)
        return self._jwk
