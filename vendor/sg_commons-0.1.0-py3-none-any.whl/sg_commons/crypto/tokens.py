"""JWT assembly/verification and opaque refresh-token helpers.

Access tokens are RS256 JWTs. We assemble the signing input by hand and hand it to a
:class:`~user_service.crypto.signer.Signer` so the same code path works whether the private
key lives in KMS or in-process.

Refresh tokens are opaque: ``"<tenant_id>.<secret>"``. The tenant prefix lets the refresh
path set RLS context (``app.tenant_id``) before the lookup; only the SHA-256 of the whole
value is stored, never the value itself.
"""

from __future__ import annotations

import base64
import hashlib
import json
import secrets
import time
import uuid
from typing import Any
from uuid import UUID

import jwt
from jwt.algorithms import RSAAlgorithm

from .signer import Signer


def _b64url(data: bytes) -> str:
    return base64.urlsafe_b64encode(data).rstrip(b"=").decode()


def encode_access_token(
    signer: Signer,
    *,
    subject: str,
    tenant_id: str,
    tenant_slug: str,
    email: str,
    issuer: str,
    audience: str,
    ttl_seconds: int,
    extra_claims: dict[str, Any] | None = None,
) -> tuple[str, dict[str, Any]]:
    """Return ``(compact_jwt, payload)`` for a freshly signed RS256 access token."""
    now = int(time.time())
    payload: dict[str, Any] = {
        "sub": subject,
        "tenant_id": tenant_id,
        "tenant_slug": tenant_slug,
        "email": email,
        "iss": issuer,
        "aud": audience,
        "iat": now,
        "nbf": now,
        "exp": now + ttl_seconds,
        "jti": uuid.uuid4().hex,
    }
    if extra_claims:
        payload.update(extra_claims)

    header = {"alg": "RS256", "typ": "JWT", "kid": signer.kid}
    signing_input = (
        f"{_b64url(json.dumps(header, separators=(',', ':')).encode())}."
        f"{_b64url(json.dumps(payload, separators=(',', ':')).encode())}"
    )
    signature = signer.sign(signing_input.encode())
    return f"{signing_input}.{_b64url(signature)}", payload


def decode_access_token(
    token: str, *, jwk: dict[str, str], issuer: str, audience: str
) -> dict[str, Any]:
    """Verify and decode an access token against a published JWK. Raises on any failure."""
    key = RSAAlgorithm.from_jwk(json.dumps(jwk))
    claims: dict[str, Any] = jwt.decode(
        token,
        key=key,  # type: ignore[arg-type]  # from_jwk returns a usable public key
        algorithms=["RS256"],
        issuer=issuer,
        audience=audience,
    )
    return claims


def _new_prefixed_token(tenant_id: UUID) -> tuple[str, str]:
    """Return ``("<tenant_id>.<secret>", sha256_hex)`` — store only the hash."""
    value = f"{tenant_id}.{secrets.token_urlsafe(32)}"
    return value, hash_token(value)


def hash_token(value: str) -> str:
    return hashlib.sha256(value.encode()).hexdigest()


def tenant_of_token(value: str) -> UUID:
    """Extract the tenant id prefix. Raises ``ValueError`` if malformed."""
    return UUID(value.split(".", 1)[0])


def new_refresh_token(tenant_id: UUID) -> tuple[str, str]:
    """Opaque rotating refresh token: ``(value, sha256_hex)``."""
    return _new_prefixed_token(tenant_id)


def new_reset_token(tenant_id: UUID) -> tuple[str, str]:
    """Opaque single-use password-reset token: ``(value, sha256_hex)``."""
    return _new_prefixed_token(tenant_id)


# Backward-compatible aliases (the scheme is shared across token kinds).
def hash_refresh_token(value: str) -> str:
    return hash_token(value)


def tenant_of_refresh_token(value: str) -> UUID:
    return tenant_of_token(value)
