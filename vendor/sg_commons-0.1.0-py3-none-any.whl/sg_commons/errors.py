"""RFC 7807 Problem Details error model + the application error hierarchy.

The platform API style guide mandates ``application/problem+json`` for all error responses, so every
``AppError`` maps to a :class:`Problem`.
"""

from __future__ import annotations

from pydantic import BaseModel


class Problem(BaseModel):
    """RFC 7807 problem details."""

    type: str = "about:blank"
    title: str
    status: int
    detail: str | None = None
    instance: str | None = None


class AppError(Exception):
    """Base application error. Subclasses set ``status``/``title``/``type``."""

    status: int = 500
    title: str = "Internal Server Error"
    type: str = "about:blank"

    def __init__(self, detail: str | None = None, *, instance: str | None = None) -> None:
        super().__init__(detail or self.title)
        self.detail = detail
        self.instance = instance

    def to_problem(self) -> Problem:
        return Problem(
            type=self.type,
            title=self.title,
            status=self.status,
            detail=self.detail,
            instance=self.instance,
        )


class NotFoundError(AppError):
    status = 404
    title = "Not Found"
    type = "https://errors.sg.local/not-found"


class UnauthorizedError(AppError):
    status = 401
    title = "Unauthorized"
    type = "https://errors.sg.local/unauthorized"


class ForbiddenError(AppError):
    status = 403
    title = "Forbidden"
    type = "https://errors.sg.local/forbidden"


class ConflictError(AppError):
    status = 409
    title = "Conflict"
    type = "https://errors.sg.local/conflict"


class ValidationError(AppError):
    status = 422
    title = "Unprocessable Entity"
    type = "https://errors.sg.local/validation"


class TooManyRequestsError(AppError):
    status = 429
    title = "Too Many Requests"
    type = "https://errors.sg.local/too-many-requests"
