"""Shared primitives for SG platform services.

Config, DB engine + RLS session helpers, crypto (RS256 signer + JWT), request-side auth, and
the RFC 7807 error hierarchy — consumed by every SG service so these primitives aren't
duplicated or allowed to drift.
"""

__version__ = "0.1.0"
