"""Short-lived **device tokens** for registered store devices (POS, KOT displays, ...).

Minted by device-service after a device proves possession of its registered key
(challenge/response). Verified by every service a device talks to: device-service (heartbeats,
photos), restaurant-mgmt (employee PIN sign-in on the device) and order-service (catalog, sync).

HS256 with a sub-key of the shared device secret (Secrets Manager
``sg/device-service/device-secret``, env ``SG_DEVICE_SECRET_ARN``); audience ``sg-device``;
claims ``sub`` (device id), ``tid`` (tenant id), ``fp`` (key fingerprint). A token only proves the
device *was* registered with that key: callers must still re-check the device row (fingerprint
unchanged -> registration not reset) before trusting it.
"""

from __future__ import annotations

import hashlib
import hmac
import os
from dataclasses import dataclass
from datetime import UTC, datetime, timedelta
from typing import Any
from uuid import UUID

import jwt

from sg_commons.config import Settings, get_settings
from sg_commons.errors import UnauthorizedError

TOKEN_AUDIENCE = "sg-device"
TOKEN_TTL = timedelta(minutes=15)
_DEV_SECRET = b"dev-only-device-secret-not-for-production"


def subkey(secret: bytes, label: str) -> bytes:
    """Derive a purpose-bound key from the device secret (HMAC-SHA256(secret, label))."""
    return hmac.new(secret, label.encode(), hashlib.sha256).digest()


@dataclass(frozen=True)
class DeviceClaims:
    tenant_id: UUID
    device_id: UUID
    fingerprint: str


def issue_device_token(
    secret: bytes,
    *,
    tenant_id: UUID,
    device_id: UUID,
    fingerprint: str,
    now: datetime | None = None,
) -> tuple[str, int]:
    now = now or datetime.now(UTC)
    claims = {
        "sub": str(device_id),
        "tid": str(tenant_id),
        "fp": fingerprint,
        "aud": TOKEN_AUDIENCE,
        "iat": int(now.timestamp()),
        "exp": int((now + TOKEN_TTL).timestamp()),
    }
    token = jwt.encode(claims, subkey(secret, "device-token"), algorithm="HS256")
    return token, int(TOKEN_TTL.total_seconds())


def decode_device_token(secret: bytes, authorization: str | None) -> dict[str, Any]:
    if not authorization or not authorization.lower().startswith("bearer "):
        raise UnauthorizedError("missing or malformed Authorization header")
    token = authorization[len("bearer ") :].strip()
    try:
        claims: dict[str, Any] = jwt.decode(
            token,
            subkey(secret, "device-token"),
            algorithms=["HS256"],
            audience=TOKEN_AUDIENCE,
            options={"require": ["exp", "sub", "tid", "fp"]},
        )
        UUID(claims["sub"])
        UUID(claims["tid"])
        return claims
    except (jwt.InvalidTokenError, ValueError, KeyError) as exc:
        raise UnauthorizedError("invalid device token") from exc


def device_claims(secret: bytes, authorization: str | None) -> DeviceClaims:
    c = decode_device_token(secret, authorization)
    return DeviceClaims(UUID(c["tid"]), UUID(c["sub"]), str(c["fp"]))


_cached: bytes | None = None


def load_device_secret(settings: Settings | None = None) -> bytes:
    """The shared device secret: Secrets Manager when ``SG_DEVICE_SECRET_ARN`` is set; a fixed
    dev value locally; fail closed when deployed (shared signing key configured) without it."""
    global _cached
    if _cached is None:
        settings = settings or get_settings()
        arn = os.environ.get("SG_DEVICE_SECRET_ARN")
        if arn:
            import boto3

            client = boto3.client("secretsmanager", region_name=settings.aws_region)
            _cached = client.get_secret_value(SecretId=arn)["SecretString"].encode()
        elif settings.kms_signing_key_id:
            raise RuntimeError("SG_DEVICE_SECRET_ARN is not configured")
        else:
            _cached = _DEV_SECRET
    return _cached
