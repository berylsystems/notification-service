"""Database engine, session helpers, and the tenant-scoped (RLS) session context.

Multi-tenancy is enforced by Postgres Row-Level Security. The application role is a
NON-superuser, so RLS applies; each unit of work opens a transaction and sets
``app.tenant_id`` via ``set_config(..., true)`` (transaction-local) — the RDS-Proxy-safe
way to scope a pooled connection to one tenant.
"""

from __future__ import annotations

import json
from collections.abc import Iterator
from contextlib import contextmanager
from urllib.parse import quote_plus
from uuid import UUID

from sqlalchemy import Engine, create_engine, text
from sqlalchemy.orm import DeclarativeBase, Session

from sg_commons.config import Settings, get_settings


class Base(DeclarativeBase):
    """Declarative base for all ORM models."""


def resolve_database_url(settings: Settings) -> str:
    """The SQLAlchemy URL to connect with.

    In AWS (``db_secret_arn`` + ``db_host`` set) the username/password are read from Secrets
    Manager and the connection is made over TLS (``db_host`` is the RDS Proxy endpoint in the
    private design, or the Aurora cluster endpoint in the DB-out-of-VPC dev design). Locally/in
    tests, the plain ``database_url`` is used.
    """
    if settings.db_secret_arn and settings.db_host:
        import boto3  # type: ignore[import-untyped]

        client = boto3.client("secretsmanager", region_name=settings.aws_region)
        secret = json.loads(
            client.get_secret_value(SecretId=settings.db_secret_arn)["SecretString"]
        )
        user = quote_plus(secret["username"])
        password = quote_plus(secret["password"])
        return (
            f"postgresql+psycopg://{user}:{password}@{settings.db_host}:"
            f"{settings.db_port}/{settings.db_name}?sslmode=require"
        )
    return settings.database_url


def make_engine(url: str | None = None) -> Engine:
    """Create a new engine. Pass ``url`` in tests; otherwise resolve from settings/secret."""
    return create_engine(
        url or resolve_database_url(get_settings()), pool_pre_ping=True, future=True
    )


_default_engine: Engine | None = None


def default_engine() -> Engine:
    """Lazily-created process-wide engine for the Lambda runtime."""
    global _default_engine
    if _default_engine is None:
        _default_engine = make_engine()
    return _default_engine


@contextmanager
def tenant_session(engine: Engine, tenant_id: UUID) -> Iterator[Session]:
    """Transaction-scoped session bound to ``tenant_id`` for RLS.

    ``set_config(key, value, is_local=true)`` keeps the setting local to this transaction,
    so a pooled / RDS-Proxy connection can never leak tenant context to the next request.
    """
    with Session(engine) as session, session.begin():
        session.execute(
            text("SELECT set_config('app.tenant_id', :tid, true)"),
            {"tid": str(tenant_id)},
        )
        yield session


@contextmanager
def admin_session(engine: Engine) -> Iterator[Session]:
    """Transaction-scoped session WITHOUT tenant context (e.g. tenant registry / slug lookup)."""
    with Session(engine) as session, session.begin():
        yield session
